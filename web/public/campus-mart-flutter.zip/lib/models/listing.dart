enum Condition { newCondition, likeNew, good, fair }

extension ConditionExtension on Condition {
  String get label {
    switch (this) {
      case Condition.newCondition:
        return 'New';
      case Condition.likeNew:
        return 'Like New';
      case Condition.good:
        return 'Good';
      case Condition.fair:
        return 'Fair';
    }
  }

  String get description {
    switch (this) {
      case Condition.newCondition:
        return 'Unopened in factory pack';
      case Condition.likeNew:
        return 'Barely used, 0 scratches';
      case Condition.good:
        return 'Normal semester wear';
      case Condition.fair:
        return 'Fully functional & working';
    }
  }
}

class Seller {
  final String name;
  final String avatar;
  final String role;
  final String department;
  final String batch;
  final bool isRollVerified;
  final double rating;
  final int peerSalesCount;
  final String replyTime;
  final String phone;

  const Seller({
    required this.name,
    required this.avatar,
    required this.role,
    required this.department,
    required this.batch,
    required this.isRollVerified,
    required this.rating,
    required this.peerSalesCount,
    required this.replyTime,
    required this.phone,
  });
}

class Listing {
  final String id;
  final String title;
  final String category;
  final Condition condition;
  final String? conditionDetail;
  final int price;
  final int originalPrice;
  final int discountPercent;
  final List<String> images;
  final String department;
  final String semester;
  final String? subjectCode;
  final Seller seller;
  final String location;
  final String handoverType;
  final String listedTimeAgo;
  final String description;
  final String? inspectionPerk;
  final bool isNegotiable;
  final bool isFeatured;

  const Listing({
    required this.id,
    required this.title,
    required this.category,
    required this.condition,
    this.conditionDetail,
    required this.price,
    required this.originalPrice,
    required this.discountPercent,
    required this.images,
    required this.department,
    required this.semester,
    this.subjectCode,
    required this.seller,
    required this.location,
    required this.handoverType,
    required this.listedTimeAgo,
    required this.description,
    this.inspectionPerk,
    this.isNegotiable = true,
    this.isFeatured = false,
  });
}

class FilterState {
  final int minPrice;
  final int maxPrice;
  final Condition? condition;
  final String department;
  final String semester;
  final String sortBy;
  final String category;
  final String searchQuery;

  const FilterState({
    this.minPrice = 0,
    this.maxPrice = 1500,
    this.condition,
    this.department = 'all',
    this.semester = '',
    this.sortBy = 'recommended',
    this.category = 'All',
    this.searchQuery = '',
  });

  FilterState copyWith({
    int? minPrice,
    int? maxPrice,
    Condition? condition,
    bool clearCondition = false,
    String? department,
    String? semester,
    String? sortBy,
    String? category,
    String? searchQuery,
  }) {
    return FilterState(
      minPrice: minPrice ?? this.minPrice,
      maxPrice: maxPrice ?? this.maxPrice,
      condition: clearCondition ? null : (condition ?? this.condition),
      department: department ?? this.department,
      semester: semester ?? this.semester,
      sortBy: sortBy ?? this.sortBy,
      category: category ?? this.category,
      searchQuery: searchQuery ?? this.searchQuery,
    );
  }
}
